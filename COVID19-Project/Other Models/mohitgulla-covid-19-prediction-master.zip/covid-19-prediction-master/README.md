# COVID-19 Data Challenge - Time Series
A time series model to predict the number of new cases, recovered patients, and deaths on May 1, 2020 across the globe.
